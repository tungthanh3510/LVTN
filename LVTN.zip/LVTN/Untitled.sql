CREATE TABLE `PRODUCT_CATEGORY` (
  `product_category_id` int PRIMARY KEY,
  `product_category_name` varchar(255)
);

CREATE TABLE `BRAND` (
  `brand_id` int PRIMARY KEY,
  `brand_name` varchar(255),
  `product_category_id` int
);

CREATE TABLE `IMAGE` (
  `product_id` int,
  `image_1` varchar(255),
  `image_2` varchar(255),
  `image_3` varchar(255),
  `image_4` varchar(255),
  `image_5` varchar(255),
  `image_6` varchar(255)
);

CREATE TABLE `PRODUCT` (
  `product_id` int PRIMARY KEY,
  `product_category_id` int,
  `product_name` varchar(255),
  `price` int,
  `description` varchar(255),
  `quantity` int,
  `brand_id` int,
  `status` varchar(255)
);

CREATE TABLE `CART` (
  `cart_id` int PRIMARY KEY,
  `product_id` int,
  `customer_id` int,
  `cart_quantity` int
);

CREATE TABLE `CUSTOMER` (
  `customer_id` int PRIMARY KEY,
  `customer_firstname` varchar(255),
  `customer_lastname` varchar(255),
  `address` varchar(255),
  `email` varchar(255),
  `phone` varchar(255),
  `birth` varchar(255),
  `password` varchar(255)
);

CREATE TABLE `ORDER` (
  `order_id` int PRIMARY KEY,
  `customer_id` int,
  `total_price` int,
  `order_address` varchar(255),
  `order_date` varchar(255),
  `payment_method` varchar(255),
  `cart_id` int
);

CREATE TABLE `ORDER_DETAILS` (
  `order_details` int PRIMARY KEY,
  `order_id` int,
  `price` int,
  `quantity` int,
  `product_id` int
);

CREATE TABLE `STAFF` (
  `staff_id` int PRIMARY KEY,
  `staff_firstname` varchar(255),
  `staff_lastname` varchar(255),
  `address` varchar(255),
  `email` varchar(255),
  `phone` varchar(255),
  `birth` varchar(255),
  `sex` varchar(255),
  `password` varchar(255),
  `role_id` int
);

CREATE TABLE `ROLE` (
  `role_id` int PRIMARY KEY,
  `role_name` varchar(255)
);

ALTER TABLE `PRODUCT` ADD FOREIGN KEY (`product_id`) REFERENCES `IMAGE` (`product_id`);

ALTER TABLE `CART` ADD FOREIGN KEY (`cart_id`) REFERENCES `ORDER` (`cart_id`);

ALTER TABLE `CUSTOMER` ADD FOREIGN KEY (`customer_id`) REFERENCES `CART` (`customer_id`);

ALTER TABLE `ORDER` ADD FOREIGN KEY (`order_id`) REFERENCES `ORDER_DETAILS` (`order_id`);

ALTER TABLE `ROLE` ADD FOREIGN KEY (`role_id`) REFERENCES `STAFF` (`role_id`);

ALTER TABLE `PRODUCT` ADD FOREIGN KEY (`brand_id`) REFERENCES `BRAND` (`brand_id`);

ALTER TABLE `BRAND` ADD FOREIGN KEY (`product_category_id`) REFERENCES `PRODUCT_CATEGORY` (`product_category_id`);
